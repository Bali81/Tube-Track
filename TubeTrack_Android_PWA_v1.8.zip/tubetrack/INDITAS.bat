@echo off
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
  start "" "http://localhost:8765/TubeTrack.html"
  py -3 -m http.server 8765 --bind 127.0.0.1
) else (
  where python >nul 2>&1
  if %errorlevel%==0 (
    start "" "http://localhost:8765/TubeTrack.html"
    python -m http.server 8765 --bind 127.0.0.1
  ) else (
    echo Python nincs telepitve vagy nem talalhato a PATH-ban.
    echo Telepitsd a Python 3-at: https://www.python.org/downloads/
    pause
  )
)
